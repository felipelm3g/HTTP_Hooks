<?php
// Arquivo em branco para evitar o acesso direto à pasta
exit;